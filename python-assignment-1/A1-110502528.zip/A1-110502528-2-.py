"""
Assignment 1
Name: 張勛皓
Student Number: 110502528
Course 2021-CE1003-A
"""

a = int(input())
b = int(input())

print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a**b)
print(a//b)
print(a%b)
