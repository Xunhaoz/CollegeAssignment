"""
Assignment 1
Name: 張勛皓
Student Number: 110502528
Course 2021-CE1003-A
"""
a = input("input1:")
b = input("input2:")
c = input("input3:")

print(c, b, a)