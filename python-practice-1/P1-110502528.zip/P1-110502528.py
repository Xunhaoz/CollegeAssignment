"""
practice 1
Name: 張勛皓
Student Number: 110502528
Course: 2021-CE1003-A
"""

a = input()

print(f"hello world {a}") 